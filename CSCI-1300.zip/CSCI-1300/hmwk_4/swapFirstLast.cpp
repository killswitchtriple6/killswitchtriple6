#include <iostream>
#include <iomanip>
using namespace std;

void swapFirstLast(int arr[], int arrElement)
{
	int j;

		j=arr[0];//finds first value
		arr[0]=arr[arrElement-1];//replaces first value with last value
		arr[arrElement-1]=j;//replaces last value with first value
}


int main()
{
	int arrElement=5;
	int arr[] = {5, 4, 3, 2, 1};
	for(int i=0; i<arrElement; i++) 
	{
		cout<<arr[i]<<endl;
	}
	cout<<" swapped values will be "<<endl;
	swapFirstLast(arr, arrElement);
	for(int i=0; i<arrElement; i++) 
	{
		cout<<arr[i]<<endl;
	}
	
}