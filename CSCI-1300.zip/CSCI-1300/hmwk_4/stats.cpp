#include <iostream>
#include <iomanip>
using namespace std;

void stats(double statArr[], int arrElement)
{
	double avg = 0.0;
	double sum = 0.0;
	double largestValue = statArr[0];
	double smallestValue = statArr[0];

		for(int i=0; i<arrElement; i++) 
		{
		      if(smallestValue>statArr[i]) 
		      {
		    	   smallestValue=statArr[i];
		      }
		}
		
		
		
		for(int i=0; i<arrElement; i++) 
		{
		      if(largestValue<statArr[i]) 
		      {
		        	 largestValue=statArr[i];
		      }
		}

		for(int i = 0; i < arrElement; i++) 
	{
		sum += statArr[i];
		avg = sum /arrElement;
	}
	
	
	cout<<"Min: "<< fixed << setprecision(2) << smallestValue <<  endl;
	cout<<"Max: "<< fixed << setprecision(2) << largestValue <<  endl;
	cout<<"Avg: "<< fixed << setprecision(2) << avg <<  endl;
}

int main()
{
	int arrElement=14;
    double statArr[]={0,11,2,3,14,5,6,17,8,19,10,21,12,23,14};//test case
	stats(statArr, arrElement);
	
}