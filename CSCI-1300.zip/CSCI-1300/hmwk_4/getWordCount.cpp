#include <iostream>
#include <string>
using namespace std;

int getWordCount(string inputWord) 
{
	bool inWord;
	int maxLength = inputWord.length();
	int wordCount = 0;
	
	if (maxLength == 0)
	{
	    return 0;
	}


    for (int i = 0; i < maxLength + 1; i++)
    {
    	
       if (inputWord[i] == ' ') 
       {
           inWord = false;
       } 
       
       if (!inWord) //every time a space is found enters the if statement
       
       {
           inWord = true;
           wordCount ++; // add to the number of words
       }
   }
   return wordCount;
}




int main()
{
    string s= "Colorless green ideas dream furiously";
    int wordCount=getWordCount(s);
	cout << wordCount <<endl;
}