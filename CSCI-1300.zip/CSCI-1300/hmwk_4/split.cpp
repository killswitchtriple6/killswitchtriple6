#include <iostream>
#include <iomanip>
using namespace std;

int split(string phrase, char delimiter, string arr[],int length)
{
	int counter = 0;
	string splitStr = "";
	
	
    if (phrase.length() == 0)
	{
		return 0;
	}
	
	for (int i = 0; i < phrase.length(); i++)
	{

    	if(phrase[i] != delimiter)
    	{
    		splitStr = splitStr + phrase[i];
    		//cout<< splitStr <<endl;
        }

	    else
	    {
	    	if(splitStr != "")
	    	{
		    	arr[counter] = splitStr;
			 	splitStr = "";
		      	counter ++;
		      	//cout<< arr <<endl;
	    	}
	    }
	}
	if (splitStr != "")
	{
		arr[counter] = splitStr;
		counter++;
	}
	return counter;
}


int main()
{
	// string phrase = "cow/chicken/fish";
	// char delimiter = '/';
	// string arr[3];
	// cout<<split(phrase, delimiter,arr,3)<<endl;
	
	string phrase = "RST,UVW,XYZ";
	char delimiter = ',';
	string arr[3];
	int testCase = split(phrase, delimiter, arr, sizeof(arr)/sizeof(phrase));
	for (int i=0 ; i < 10 && i < testCase ; i++)
	cout << "my_array["<< i << "]:" << arr[i] << endl;
	cout << "Function returned value: " << testCase << endl;
	
}