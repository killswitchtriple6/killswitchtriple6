#include <iostream>
#include <string>
using namespace std;



int main()
{
	const int numScores=0;
	const int tempInit = 10;
	const int colorChoice = 5;
	const int seqNum = 100;
	const int seqLetter = 26;
	
	double temps[tempInit];
	for(int i = 0; i < 10; i++) 
	{
		temps[i] = -459.67;
	}
	
	for(int i = 0; i < 10; i++) 
	{
		cout<< temps[i] <<endl;
	}
	
	
	
	
	
	string color[colorChoice]={"Red", "Blue", "Green", "Cyan", "Magenta"};
	
	for(int i = 0; i < 5; i++) 
	{
		cout<< color[i] <<endl;
	}
	
	
	
	int numberSequence[seqNum];
	int n = 1;
	for(int i = 0; i< seqNum; i++)
	{
		numberSequence[i] = n;
		n++;
	}
	for(int i = 0; i < seqNum; i++)
	{
		cout << numberSequence[i]<<endl;
	}
	
	
	
	
	
	
	
	char letterSequenceUpper[seqLetter];
	
	int j=65;
		for (int i = 0; i<seqLetter; i++)
		{
			letterSequenceUpper[i] = j;
			j++;
		}
		
	char letterSequenceLower[seqLetter];	
	
	int k=97;
		for(int i = 0; i<seqLetter; i++)
		{
			letterSequenceLower[i] = k;
			k++;
		}
	for(int i = 0; i<26; i++)
		{
			cout<< letterSequenceUpper[i]<<" "<< letterSequenceLower[i]<<endl;
		}
		
	return 0;
}