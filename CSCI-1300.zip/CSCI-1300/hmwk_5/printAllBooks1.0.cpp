#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

using namespace std;
string printAllBooks(string titles[],string authors[],int numOfBooks)
{

   if (numOfBooks <=0)//edge case check
   {
      cout<< "No books are stored"<<endl;
   }
   else
   {
      cout<<"Here is a list of books "<<endl;
      for(int i=0; i < numOfBooks; i++)
      {
         cout << titles[i] << " by " << authors[i] << endl;// prints titles by authors in respective index
      }   
   }
}

int main()
{
    string book_titles[] = {"Calculus", "Algebra", "Physics"};
    string book_authors[] = {"Gottfried Leibniz", "Alan Turing", "Isaac Newton"};
    printAllBooks(book_titles, book_authors, 3);
}
