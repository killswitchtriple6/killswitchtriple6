#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

using namespace std;

int getLinesFromFile(string fileName,int arr[],int len)
{
   int i = 0;
   string lines;
   
   ifstream inputFile;
   inputFile.open(fileName);
   
   if (inputFile.is_open())
   {
      while(getline(inputFile, lines))
      {
         if (i>len)//edge case check
         {
            return i;
         }
         if(lines.length() != 0) 
         {
            arr[i] = stoi(lines);// stores the value at i into lines as an integer
            i++;
         }
         
      }

   }
   else
   {
       return -1;
   }
   
   inputFile.close();
   return i;
 
}

int main()
{
   string fileName = "numbers.txt";
   int arr[10];
   int count = getLinesFromFile(fileName, arr, 10);
   for (int i=0; i<count; i++)
   {
      cout<< arr[i]<<endl;
   }
}