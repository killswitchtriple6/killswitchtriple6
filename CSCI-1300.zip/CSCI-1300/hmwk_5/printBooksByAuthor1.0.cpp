#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

using namespace std;

void printBooksByAuthor(string titles[],string authors[],int numOfBooks, string authorName)
{
   int authorCount=0;
   if (numOfBooks <=0)//edge case check
   {
      cout<< "No books are stored"<<endl;
      return;
   }
   
   for(int i = 0; i < numOfBooks; i++) 
   {
      if(authors[i] == authorName)
      {
         authorCount++;
      }
   }
   if (authorCount <= 0)//edge case check
   {
      cout<<"There are no books by "<< authorName<<endl;
      return;
   }
   cout<<"Here is a list of books by "<< authorName <<endl;
   for(int i=0; i < numOfBooks; i++)
   {
      if (authors[i] == authorName)
      {
         cout << titles[i] << endl;
         authorCount++;
      }
   }
}

int main()
{
   string book_titles[] = {"Book 1", "Book 2", "Book 3", "Book 4"};
   string book_authors[] = {"Author A", "Author B", "Author C", "Author A"};;
   int numberOfBooks = 4;
   string author = "Author A";
   printBooksByAuthor(book_titles, book_authors, numberOfBooks, author);
}