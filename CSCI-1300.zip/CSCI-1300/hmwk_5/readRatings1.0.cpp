#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

using namespace std;
int split(string phrase, char delimiter, string arr[],int length)
{
	int counter = 0;
	string splitStr = "";
	
	
    if (phrase.length() == 0)
	{
		return 0;
	}
	
	for (int i = 0; i < phrase.length(); i++)
	{

    	if(phrase[i] != delimiter)
    	{
    		splitStr = splitStr + phrase[i];
        }

	    else
	    {
	    	if(splitStr != "")
	    	{
		    	arr[counter] = splitStr;
			 	splitStr = "";
		      	counter ++;
	    	}
	    }
	}
	if (splitStr != "")
	{
		arr[counter] = splitStr;
		counter++;
	}
	return counter;
}

int readRatings(string fileName, string users[],int ratings[][50],int numUsers, int maxRows, int maxColumn)
{
    char delimiter= ',';
    string splitArr[51];
    string lines;
    ifstream inputFile;
    inputFile.open(fileName);
    if (numUsers == maxRows)//edge case check
    {
        return -2;
    }
    if(inputFile.fail())//edge case check
    {
        return -1;
    }
    
	if (inputFile.is_open())
	{
		
        if (numUsers == maxRows)//edge case check
        {
            return -2;
        }
        while(getline(inputFile, lines) && numUsers < maxRows)
        {
            if (lines == "")//edge case check
            {
            	lines = "";
            }
            if(lines.length()==0)//edge case check
            {
            	continue;
            }
            if(numUsers >= maxRows)//edge case check
            {
            	break;
            }
            else
            {
            	int numSplit = split(lines, delimiter, splitArr, numUsers);
            	users[numUsers]=splitArr[0];.// stores the value at numUsers into splitArr at index 0
            	for(int i=1; i<numSplit; i++)
    	            {
    	                  ratings[numUsers][i-1]= stoi(splitArr[i]);// stores the value at i-1 into lines as an integer
    	            }
    	    numUsers++;
            }
        }
    return numUsers;
	}
	inputFile.close();
}

int main()
{
string users[10] = {};
int ratings[10][50] = {{0}};
int numUsers = 0;
int maxRows = 10;
int maxColumns = 50;
int numBooks = 5; // (we know it's 5 books)
numUsers = readRatings("ratings_2.txt", users, ratings, numUsers, maxRows, maxColumns);
numUsers = readRatings("ratings_1.txt", users, ratings, numUsers, maxRows, maxColumns);

cout << "Function returned value: " << numUsers << endl;


}