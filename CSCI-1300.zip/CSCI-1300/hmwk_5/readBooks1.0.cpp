#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

using namespace std;

int split(string line, char delimiter, string arr[])
{
    int i=0;
    int j=0;
	int counter = 0;
	string tempSplitStr = "";
	
	
    if (line.length() == 0)
	{
		return 0;
	}
	line = line + delimiter;
	for (i = 0; i < line.length(); i++)
	{

    	if(line[i] != delimiter)
    	{
    		tempSplitStr += line[i];
        }

	    else
	    {
	    	if(tempSplitStr != "")
	    	{
		    	arr[j] = tempSplitStr;
			 	tempSplitStr = "";
		      	j++;
	    	}
	    }
	}
	return counter;
}


int readBooks(string fileName, string titles[],string authors[],int numBookStored, int size)
{
    int i = 0;
    int lineCounter = numBookStored;
    char delimiter= ',';
    string splitVal[2];
    string lines;
    ifstream inputFile;
    inputFile.open(fileName);
    
    if(inputFile.fail())//edge case check
    {
        return -1;
    }
   if (inputFile.is_open())
   {

        if (numBookStored == size)//edge case check
        {
            return -2;
        }
      while(getline(inputFile, lines) && lineCounter < size)
      {
        if (lines== "")//edge case check
        {
            lines = "";
        }
        
        else 
        {
            split(lines, delimiter, splitVal);
            authors[lineCounter]= splitVal[0];//stores values from author into new array at index 0
            titles[lineCounter]= splitVal[1];//stores values from titles into new array at index 1
             
            lineCounter++;
        }
         
      }

   }
   

    return lineCounter;
   inputFile.close();
}

int main()
{
    string fileName = "books.txt";
    int numBookStored = 0;
    string titles[50];
    string authors[50];
    int size = 50;
    int count = readBooks(fileName,titles, authors, numBookStored, size);
    cout<<count<<endl;
    for (int i=0; i<count; i++)
      {
          cout<< titles[i]<<endl;
          cout<<authors[i]<<endl;
      }
//test case that prints every book in the text file
}