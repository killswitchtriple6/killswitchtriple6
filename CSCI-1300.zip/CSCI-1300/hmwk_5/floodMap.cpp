#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

using namespace std;

void floodMap(double mapArr[][4], int rows, double waterLvl)
{
   for(int i=0; i<rows; i++)
   {
      for(int j=0; j<4; j++)
      {
         if(mapArr[i][j] > waterLvl)//if the value in the array is less than the waterLvl print the underscore
         {
            cout<< "_";
         }
         else//if not then print the asterisk
         {
            cout<<"*";
         }
      }
      cout<<endl;
   }
}

int main()
{
   double mapArr[4][4] = {{5.9064, 15.7541, 6.11483, 11.3928}, {16.8498, 5.736, 9.33342, 6.36095}, {3.18645, 16.935, 4.7506, 9.63635}, {2.22407, 0.815145, 0.298158, 13.466}};
   floodMap(mapArr, 4, 9.3);
}
