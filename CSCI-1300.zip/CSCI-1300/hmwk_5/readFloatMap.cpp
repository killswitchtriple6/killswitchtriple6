#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

using namespace std;

int split(string line, char delimiter, string arr[])
{
    int i=0;
    int j=0;
	int counter = 0;
	string tempSplitStr = "";
	
	
    if (line.length() == 0)
	{
		return 0;
	}
	line = line + delimiter;
	for (i = 0; i < line.length(); i++)
	{

    	if(line[i] != delimiter)
    	{
    		tempSplitStr += line[i];
        }

	    else
	    {
	    	if(tempSplitStr != "")
	    	{
		    	arr[j] = tempSplitStr;
			 	tempSplitStr = "";
		      	j++;
	    	}
	    }
	}
	return counter;
}


int readFloatMap(string fileName,double floatMap[][4],int rows)
{
    int i = 0;
    int size = fileName.length();
    int lineCounter = 0;
    char delimiter= ',';
    string splitMap[4];
    string lines;
    ifstream inputFile;
    inputFile.open(fileName);
    
    
    if(inputFile.fail())//edge case check
    {
        return -1;
    }
   if (inputFile.is_open())
   {

        if (rows == size)//edge case check
        {
            return -2;
        }
        
        while(getline(inputFile, lines) && lineCounter < size)
        {
        if(i == rows)//edge case check
        {
            return lineCounter;
        }
        if (lines == "")//edge case check
        {
            lines = "";
        }
        
        else 
        {
        split(lines, delimiter, splitMap);
            for(int j=0; j<4; j++)// for loop to run through each 
            {
                floatMap[i][j] = stod(splitMap[j]);//stod converts string to decimal
            }
            i++;
            lineCounter++;
        }
         
      }

   }
    return lineCounter;
   inputFile.close();
}

int main()
{
    	
double floatMap[2][4];
int x = readFloatMap("floodMap.txt", floatMap, 2);//uses values from floodMap.txt
cout << "Function returned: " << x << "\n";
for(int i = 0; i < 2; i++)
    {
        cout << floatMap[i][0] << ", " << floatMap[i][1] << ", " << floatMap[i][2] << ", " << floatMap[i][3] << "\n";
    }
}//test case taken from code runner