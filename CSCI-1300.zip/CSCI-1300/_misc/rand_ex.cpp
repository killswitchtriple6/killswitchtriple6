//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <stdlib.h>
#include <ctime>
#include <vector>

using namespace std;

int rollDice()
{
	srand(time(NULL));
	int x = rand() %1 00 + 1;
	return x;
}

int main()
{
	int value = rollDice();
	if(value <=60)
	{
		cout<<"generated less than 60"<<endl;
	}
	else//number generated was above 60, below 100(threshhold)
	{
		cout<<"generated more than 60 and less than 100"<<endl;
	}
	
	// //rand example
	// srand(time(0));
	// srand(time(NULL));
	// srand(time(nullptr));
	// int value = rand() % 100 + 1;//generates a random number up to RAND MAX
	// cout<<value<<endl;
	// return 0;
}