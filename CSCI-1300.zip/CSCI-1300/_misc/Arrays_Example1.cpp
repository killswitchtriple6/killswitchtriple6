//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni


#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>

using namespace std;

int main()
{
	//invalid conversion from const char* to 
	//char* -> a memory address which holds a char 
	int x[3];
	cout<< x << endl;
}