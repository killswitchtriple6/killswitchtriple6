#include <iostream>
#include <iomanip>
using namespace std;

void celsiusToFahrenheit(int temp_C)
{

    // convert for fahrenheit
    double temp_F = (9.0/5.0)* temp_C + 32.0;
    //print answer
    cout << "The temperature of " << temp_C << " in Fahrenheit is "<< fixed << setprecision(2) << temp_F << endl;
}

int main()
{
   // cout << "what is the temperature in C?" << endl;
    // get value in celsius
     int temp_C = 38;
  //  double temp_C;
    //cin >> temp_C;
    celsiusToFahrenheit(temp_C);
     
     return 0;
}
