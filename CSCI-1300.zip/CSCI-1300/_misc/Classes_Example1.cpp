//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni


#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>

using namespace std;

class Sailboat
{
	public:
	string name;
	int length;
};

Sailboat* sailboatFactory()
{
	//instead of stack allocating sailboat
	//Sailboat t;
	
	//allocate it on the heap
	Sailboat* t = new Sailboat();
	//these are the same line
	//t->name = "New boat";
	//t->length = 32;
	(*t).name = "New boat";
	(*t).length = 32;
	return t;
}

int main()
{
	Sailboat* newSailboat = sailboatFactory();
	(*newSailboat).length = 64;
	cout<< (*newSailboat).name << " "<< (*newSailboat).length <<endl;
	
	//necessary, so that memory leaks don't occur
	delete newSailboat;
}