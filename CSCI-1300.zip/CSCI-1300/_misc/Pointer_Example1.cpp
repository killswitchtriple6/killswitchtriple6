//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>

using namespace std;

class point
{
	private:
	int px;
	int py;
};

int main()
{
	int x;
	//give me the address that px lives at
	cout << &x << endl;
	
	point p;
	cout<< &p<<endl;
	
	int y  = 7;//value to send to memory
	
	//pointer is used to store a memory address
	int * pointer = &y;
	cout<< pointer <<endl;
	
	//dereference the pointer to print it
	cout<< *pointer <<endl;
	
	//dereference the pointer to change it
	*pointer = 32;
	cout<< *pointer <<endl;
}