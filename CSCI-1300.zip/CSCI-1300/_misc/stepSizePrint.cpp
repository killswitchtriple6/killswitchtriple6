//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni
//Homework () - Problem ()

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>

using namespace std;

void stepSizePrint (int startPoint, int endPoint, int stepSize)
{
   int stepVal = 0;
   int newStepVal = 0;
   if (stepSize == 0)
   {
      cout<< "Step size cannot be zero."<<endl;
   }
   if (startPoint >= endPoint || endPoint < startPoint)
   {
      cout<<"Wrong settings!"<<endl;
   }
   for (int i=startPoint; i < endPoint; i++)
   {
      stepVal = newStepVal;
      stepVal = startPoint + stepSize;
      if (stepVal > newStepVal)
      {
         newStepVal = stepVal;
      }
      cout<<stepVal<<endl;
   }
}

int main()
{
	cout << "Hello from AWS Cloud9!" << endl;
}