//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni


#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>

using namespace std;

//a memory address of 0 is a null pointer
void printPtr(int*x)
{
	cout<<*x<<endl;
}

int main()
{
	int* y;
	cout<< y << endl;
	printPtr(y);
}