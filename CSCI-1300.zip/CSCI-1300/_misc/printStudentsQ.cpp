//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>

using namespace std;

int split(string phrase, char delimiter, string arr[],int length)
{
	int counter = 0;
	string splitStr = "";
	
	
    if (phrase.length() == 0)
	{
		return 0;
	}
	
	for (int i = 0; i < phrase.length(); i++)
	{

    	if(phrase[i] != delimiter)
    	{
    		splitStr = splitStr + phrase[i];
    		//cout<< splitStr <<endl;
        }

	    else
	    {
	    	if(splitStr != "")
	    	{
		    	arr[counter] = splitStr;
			 	splitStr = "";
		      	counter ++;
		      	//cout<< arr <<endl;
	    	}
	    }
	}
	if (splitStr != "")
	{
		arr[counter] = splitStr;
		counter++;
	}
	return counter;
}



int PrintStudents(string fileName, int minScore, string outputFile)
{
    string line ="";
    int score = 0;
    int count = 0;
    string tempArr[3];
    
    ifstream inFile;
    inFile.open(fileName);
    
    if (inFile.is_open())
    {
        ofstream outFile;
        outFile.open(outputFile);
        
        if (outFile.is_open())
        {
            while (getline (inFile, line))
            {
                split(line, ',', tempArr, 3);
                score = stoi(tempArr[1]);
                if(score >= minScore)
                {
                    outFile << tempArr[0] << ","<< tempArr[2]<<endl;
                }
            count ++;
            }
        }
        else
        {
            return -1;
        }
        outFile.close();
    }
    else
    {
        return -1;
    }
    inFile.close();
    return count;
}

int main()
{
    int x, y, z;
    return 0;
}