//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni
//Homework () - Problem ()

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>

using namespace std;

void DayOfWeek(int dayOfWeek)
{
   if (dayOfWeek == 0 || dayOfWeek == 6)
   {
       cout<<"SLEEPDAY"<<endl;
   }
	else if (dayOfWeek == 1)
   {
       cout<< "MONDAY"<<endl;
   }
    else if (dayOfWeek == 5)
   {
   		cout<<"FUNDAY"<<endl;
   }
	else if (dayOfWeek > 2 && dayOfWeek <=4 )
   {
		cout<<"WORKDAY"<<endl;
   }
   else
   {
   	cout<<"INVALID"<<endl;
   }
}

int main()
{
	cout << "Hello from AWS Cloud9!" << endl;
}