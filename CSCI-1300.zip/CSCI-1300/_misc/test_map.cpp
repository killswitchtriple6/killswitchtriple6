//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>

using namespace std;

int main()
{
	int rows = 3;
	int columns = 3;
	char array[3][3] = 
	{
	{'K','A','R'},
	{'P','K','C'},
	{'Z','A','R'}	
	};
	int startI=0;
	for (int i=startI; i<= startI + 2; i++ )
	{
		int startJ=0;
		for(int j=startJ;j<=startJ + 2;j++ )
		{
			cout<<array[i][j]<<endl;
		}
	}
	return 0;
}