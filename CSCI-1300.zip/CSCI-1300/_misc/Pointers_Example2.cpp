//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni


#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>

using namespace std;

//pointers
//star = raw pointers
int modifyNum(int* point)
{
	//dereference pointer to change value
	int y = 10;
	point = &y;
	*point = 9;
}

//pass by reference -  syntactic sugar
void modifyReference(int& x)
{
	x = 27;
}

int main()
{
	int x = 3;
	//int* pointer = &x;
	//modifyNum(&x);//passes the memory address to the function
	modifyReference(x);
	cout << x << endl;
}