//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>

using namespace std;
int main()
{
    string line = "#Sko #Buffs";
    string temp= "";
    string delimiter;
    
    for (int i=0; i < line.length(); i++ )
    {
        if(line[i] != delimiter)
        {
            temp += line[i];
        }
        else
        {
            line[i] = "@";
        }
    }
    cout<<temp<<endl;
}