//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni


#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>

using namespace std;

class Trainer;

class Pokemon
{
	public:
	Trainer* t;
	int y;
};

class Trainer
{
	public:
	Pokemon pokemon[6];
	int x;
};

int main()
{
	Pokemon p;
	//garbage value
	cout<<"garbage value: "<< p.t<<endl;
	
	Trainer trainer;
	p.t = &trainer;
	
	cout<<p.t<<endl;
	
}