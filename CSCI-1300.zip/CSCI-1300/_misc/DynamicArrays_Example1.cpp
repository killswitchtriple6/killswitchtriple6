//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni


#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>

using namespace std;

int main()
{
	int size;
	cout<<"Enter the size of the array you want: "<<endl;
	cin>>size;
	//int x[size];
	
	//asking compiler to give you stack space
	int x[3];
	
	cout<< x <<endl;
	//malloc -  asks OS for memory
	//use the memory to create an array
	int* arr = new int[size];
	cout<< arr <<endl;
	
	arr[2] = 3;
	arr[1] = 67;
	
	cout<<arr[100]<<endl;
	//free() - c library function
	//do one delete for every new array
	delete[] arr;//delete[] -c++ library function
	
}