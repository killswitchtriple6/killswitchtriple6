//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>

#ifndef EMPLOYEE_H
#define EMPLOYEE_H
using namespace std;

class Employee
{
	private:
	string employeeName;
	string jobTitle;
	int salary;
	int yearsEmployed;
	int roomNumber;
	
	public:
	Employee();
	Employee(string, string, double, int, int);
	
	//getters
	string getName();
	//setters
	void setName(string);
};
#endif