//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>
#include "Employee.h"

#ifndef ROOM_H
#define ROOM_H
using namespace std;

class Room
{
	private:
	int capacity;
	bool inUse;
	char roomChar;//determines what type of room is in the office
	
	
	public:
	char getChar()
	
};
#endif