//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>
#include "Employee.h"

#ifndef OFFICE_H
#define OFFICE_H
using namespace std;

class Office
{
	private:
	vector<Employee> officeEmployees;
	Room officeSpaces[3][3];//locations within one object
	
	public:
	
	//constructors
	Office();
	{
		officeSpaces = {{'K','A','R'},
						{'P','K','C'},
						{'Z','A','R'}};
		rows = 3;
		columns
		
	}
	Office(/*variables for parametized constructor*/);
	
	int getNumEmployees()
	{
		return officeEmployees.size();
	}
	
	void printOffice()
	{
		int i=0;
		for (i=0; i<rows; i++ )
		{
			int j=0;
			for(j=0;j<columns;j++ )
			{
				cout<<officeSpaces[i][j].getChar()<<endl;
			}
		}
	}
	
	
};
#endif