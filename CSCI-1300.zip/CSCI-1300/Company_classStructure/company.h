//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>
#include "office.h"

#ifndef COMPANY_H
#define COMPANY_H
using namespace std;

class Company
{
	private:
	Employee officeManager[100];
	Customer[100];
	vector<Office> offices;
	int numEmployees;
	
	public:
	
	int getTotalNumEmployees()
	{
		int sum = 0;
		for(int i=0; i < offices.size(); i++)
		{
			//sum = sum + offices.at(i).getNumEmployees();
			Office tempOffice = offices.at(i);
			sum += tempOffice.at(i).getNumEmployees();
		}
	return sum; 
	}
	
	//constructors
	
};
#endif