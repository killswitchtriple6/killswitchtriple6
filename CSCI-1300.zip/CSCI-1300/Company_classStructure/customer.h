//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include <vector>

#ifndef CUSTOMER_H
#define CUSTOMER_H
using namespace std;

class Customer
{
	private:
	string customerName;
	int age;
	string region;
	string emailAddress;
	double money;
	
	public:
	
};
#endif