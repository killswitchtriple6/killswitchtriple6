#include <iostream>

int main()
{
	std::cout << "Hello from AWS Cloud9!" << std::endl;
}