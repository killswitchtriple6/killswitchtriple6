#include <iostream>

using namespace std; 


bool checkLeapYear (int year){
if (year%4==0 ){// if it's divisible by 4 then enter second if statement
	    if(year%400!=0 && year%100==0 && year >= 1582){
	        return false;
	    }
	return true;
	}
	return false;
	
}

int main(){
	bool year=checkLeapYear(1700); // test for bool value 1
	cout<< year<< endl ;
	year=checkLeapYear(1500); //test for bool value 2
	cout<< year<< endl ;
}