#include <iostream> 

using namespace std; 

void chessBoard (char letter, int number){
    if ((letter== 'a' || letter == 'c' || letter == 'e' || letter == 'g') && ( number % 2 == 0 && number <=8  )){ //checks if char is a,c,e,g and remainder is 0
        cout << "white" << endl ;
    }
    else if ((letter== 'b' || letter == 'd' || letter == 'f' || letter == 'h' ) && ( number % 2 == 1 && number <=8 )){//checks if char is b,d,f,h and remainder is 1
        cout << "white" << endl ;
    }
    else if((letter== 'a' || letter == 'c' || letter == 'e' || letter == 'g') && ( number % 2 == 1 && number <=8 )){//checks if char is a,c,e,g and remainder is 1
        cout << "black"<< endl;
    }
    else if((letter== 'b' || letter == 'd' || letter == 'f' || letter == 'h' ) && ( number % 2 == 0 && number <=8 )){//checks if char is b,d,f,h and remainder is 0
        cout << "black"<< endl;
    }
    else{
        cout << "Chessboard squares can only have letters between a-h and numbers between 1-8."<< endl;
    }

    
}

int main()
{
    int num;
    
    chessBoard ('g', 5);// test case 1

    chessBoard ('d', 3);//test case 2

    chessBoard ('a', 1);//test case 3
    
    chessBoard('B', 5);//test case 4
    
    chessBoard('e', 9);//test case 5

	return 0;
}