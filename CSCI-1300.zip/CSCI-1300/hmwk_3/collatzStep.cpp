#include <iostream>

using namespace std; 

int collatzStep (int num){
    
    if (num % 2 == 0 ){ //checks if remainder is 0
        num = num / 2;
    }
    else if (num % 2 == 1) { //checks if remainder is 1
       num = (num*3)+1;
    }
    else { //checks if num = 0
        num = 0;
    }
    return num;
}

 
int main(){
    int num;
    cout << collatzStep(4)<< endl;// test case 1
    cout << collatzStep(0)<< endl;// test case 2

	return 0;
}
