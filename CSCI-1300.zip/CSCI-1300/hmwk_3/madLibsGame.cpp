#include <iostream>
using namespace std;

int story ()
{
 int choice;
	
	while (choice !=4)
	{
		cout << "Which story would you like to play? Enter the number of the story (1, 2, or 3) or type 4 to quit"<< endl;
		cin >> choice;
		
		if(choice != 1 && choice != 2 && choice != 3 && choice != 4)
		{
			cout<< "Invalid, enter the number of the story (1, 2, or 3) or type 4 to quit"<< endl;
			continue;
		}
			
		if (choice == 1)
		{
			string noun;
			cout<< "Enter a noun: " << endl;
			cin >> noun;
			cout<< "Be careful not to vacuum the "<< noun << " when you clean under your bed."<< endl << endl;
		}
		else if (choice == 2)
		{
			string name;
			string occupation;
			string place;
			cout<< "Enter a name: "<< endl;
			cin >> name;
			cout<< "Enter an occupation: "<< endl;
			cin >> occupation;
			cout<< "Enter a place: "<< endl;
			cin >> place;
			cout << name << " is a "<< occupation << " who lives in "<< place << endl << endl;
		}
		else if (choice == 3)
		{
			string noun;
			string occupation;
			string animal;
			string place;
			cout<< "Enter a plural noun: "<< endl;
			cin >> noun;
			cout<< "Enter an occupation: "<< endl;
			cin >> occupation;
			cout<< "Enter an animal:"<< endl;
			cin >> animal;
			cout<< "Enter a place: "<< endl;
			cin >> place;
			cout<< "In the book War of the "<< noun << " , the main character is an anonymous " << occupation<< " who records the arrival of the "<< animal << " in "<< place << "s. " << endl << endl;
		}
	}
	if (choice == 4)
	{
		cout << "Good bye!" << endl;
	}
}

int main()
{
		story ();
}