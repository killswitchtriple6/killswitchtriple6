#include <iostream>
using namespace std; 

void checkEqual (int n1, int n2, int n3){

    
    if ((n1 == n2) && (n2 == n3) && (n1 == n3)){// checks if n1, n2, and n3 is the same
        cout << "All same" << endl;
    }
    else if ((n1 != n2) && (n2 != n3) && (n1 != n3)){// checks if n1, n2, and n3 different
        cout << "All different" << endl;
    }
    else{
        cout <<"Neither" << endl;  
    }
    
}
int main()
{
    int n1, n2, n3;
    checkEqual( 1, 2, 2);//test case

	return 0;
}