#include <iostream>

using namespace std; 

void printGrid (int n){
	if (n>0){
	for (int i = 0; i<=n; i++ ){
		
		for (int a = 0; a<n; a++){// for every row print +--
			cout<< "+--";
		}
		cout<<"+"<<endl; //print the last + and move down a line
		if(i < n){
		for (int j = 0; j<n; j++){// for every column print |
			cout<< "|  ";
		}
		cout<<"|"<<endl;//print the last | and move down a line
		}
	}
	}
	else{
		cout<<"The grid can only have a positive number of rows and columns."<<endl;
	}
}

int main(){
	// int n;
	// cout <<"enter a number"<< endl;
	// cin >> n ;
	// printOddNumsWhile(n);
	printGrid(3);//test case 1
	printGrid(-6);//test case 2


}