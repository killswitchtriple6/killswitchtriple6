#include <iostream>

using namespace std; 

void printOddNumsWhile (int n){
int i=1;

	while (i<=n){
		cout << i << endl; //prints i first
		i = i+2;
	}
}
int main(){
	// int n;
	// cout <<"enter a number"<< endl;
	// cin >> n ;
	// printOddNumsWhile(n);
	printOddNumsWhile(13);//test case 1
	printOddNumsWhile(25);//test case 2
	printOddNumsWhile(39);//test case 3

}