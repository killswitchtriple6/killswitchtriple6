#include <iostream>
using namespace std; 

int countDigits (int digits){
    int mod = 0;
        if (digits < 0 ){
            digits = digits * -1;
        }
    while (digits > 9){
        if (digits % 10 >= 0 ){
          mod++;
          digits = digits / 10;// checks how many times the number can be divided by 10.
    }
}
    mod++;
    cout << mod << endl;
    return mod;
}
int main()
{
    countDigits(739);//test case 1
    countDigits(-2305);//test case 2
    countDigits(-99999);//test case 3

	return 0;
}