#include <iostream>

using namespace std; 


void printCollatz (int num){

	if (num<=0){
		cout << "invalid number" << endl;// checks if number is less than 0
	}
	else{
			cout << num << " ";
		while (num>1){
			if (num % 2 ==0){// if even divide by 2
				num=num / 2;
				cout << num <<" ";
			}
			else if (num % 2 ==1){//if odd multiply by 3 and add 1
				num=(num*3) +1;
				cout << num <<" ";
				}
			}
		}
}




int main(){
	int num;
    printCollatz(-5);// test case 1
    printCollatz(3);// test case 2

	return 0;
}
