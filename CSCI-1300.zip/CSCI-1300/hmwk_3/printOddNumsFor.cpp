#include <iostream>

using namespace std; 

void printOddNumsFor(int n){
	for (int i=1; i<=n; i = i+2){
		cout << i << endl;//prints i first
	}
}
int main(){
	// int n;
	// cout <<"enter a number"<< endl;
	// cin >> n ;
	// printOddNumsfor(n);
	printOddNumsFor(13);//test case 1
	printOddNumsFor(25);//test case 2
	printOddNumsFor(39);//test case 3
}