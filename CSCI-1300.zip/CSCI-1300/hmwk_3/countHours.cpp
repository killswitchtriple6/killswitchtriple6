#include <iostream>

using namespace std; 


int countHours (int month){
	int day= 24;//hours in a day
	switch(month){
		case 1:{
			return day*31;//jan
			break;
		}
		case 2:{
			return day*28;//feb
			break;
		}
		case 3:{
			return day*31;//mar
			break;
		}
		case 4:{
			return day*30;//apr
			break;
		}
		case 5:{
			return day*31;//may
			break;
		}
		case 6:{
			return day*30;//jun
			break;
		}
		case 7:{
			return day*31;//jul
			break;
		}
		case 8:{
			return day*31;//aug
			break;
		}
		case 9:{
			return day*30;//sep
			break;
		}
		case 10:{
			return day*31;//oct
			break;
		}
		case 11:{
			return day*30;//nov
			break;
		}
		case 12:{
			return day*31;//dec
			break;
		}
		default:{
			cout<<"Invalid month"<< endl;
		}
	}
	
}

int main(){
	int month = 0;
	cout << "Enter a month "<< endl;// test for month
	cin >> month;
	countHours(month);
	return 0;
}