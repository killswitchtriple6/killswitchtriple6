//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni
//Homework 6 - Problem 2

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include "planet.h"
#include "planet.cpp"

using namespace std;

double maxRadius(Planet planetArr[],int size)
{
	string name;
	double maxRad = 0;
	double volume =0;
	int index = -1;
	

	for(int i = 0; i<size; i++ )
	{
		if (planetArr[i].getName() == "")
	{
		return -1;
	}
		string tempName = planetArr[i].getName();
		double tempRadius = planetArr[i].getRadius();
		double tempVoume = planetArr[i].getVolume();
		if(tempRadius > maxRad)
		{
			name = tempName;
			maxRad = tempRadius;
			volume = tempVoume;
			index = i;
		}
	}
	
	return index;
}

int main()
{
	Planet planets[5];
	planets[0] = Planet("On A Cob Planet",1234);
	planets[1] = Planet("Bird World",4321);
	int idx = maxRadius(planets, 2);
	cout << planets[idx].getName() << endl;
	cout << planets[idx].getRadius() << endl;
	cout << planets[idx].getVolume() << endl;
}