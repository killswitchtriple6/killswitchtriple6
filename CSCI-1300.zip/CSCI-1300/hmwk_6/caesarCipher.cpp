//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni
//Homework 6 - Extra Credit 1

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>

using namespace std;

string keywordCipher(string message, string key, bool flag) 
{ 
	int j;
	string newMessage = ""; 
	if (flag == true)//encrypt
	{

		// traverse text 
		for (int i=0;i<message.length();i++) 
		{
		    message[i]=key[j];
		} 
	}

	// Return the resulting string 
	return newMessage; 
} 

 
int main() 
{ 
	string message="ATTACKATONCE"; 
	int key = 4; 
	cout << "Text : " << message; 
	cout << "\nShift: " << key; 
	cout << "\nCipher: " << keywordCipher(message, key); 
	return 0; 
} 
