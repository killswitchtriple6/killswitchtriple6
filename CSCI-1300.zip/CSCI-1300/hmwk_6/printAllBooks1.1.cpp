//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni
//Homework 6 - Problem 5


#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include "book.h"

using namespace std;
void printAllBooks(Book books[],int numOfBooks)
{

   if (numOfBooks <=0)//edge case check
   {
      cout<< "No books are stored"<<endl;
   }
   else
   {
      cout<<"Here is a list of books "<<endl;
      for(int i=0; i < numOfBooks; i++)
      {
         cout << books[i].getTitle() << " by " << books[i].getAuthor() << endl;// prints titles by authors in respective index
      }  
   }
}

//Use printAllBooksUnity for testing

int main()
{
   // print three books
   Book books[3];
   int numOfBooks = 3;
   
   // putting books in the books array
   books[0].setTitle("Calculus");
   books[0].setAuthor("Gottfried Leibniz");
   
   books[1].setTitle("Algebra");
   books[1].setAuthor("Alan Turing");
   
   books[2].setTitle("Physics");
   books[2].setAuthor("Isaac Newton");
   
   printAllBooks(books, 3);
}
