//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni
//Homework 6 - Problem 7
#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include "book.h"

using namespace std;
void printMenu()
{
    cout << "======Main Menu=====" << endl;
    cout << "1. Read books" << endl;
    cout << "2. Print all books" << endl;
    cout << "3. Print books by author" << endl;
    cout << "4. Quit" << endl;
}


//readBooks
int split(string line, char delimiter, string arr[])
{
    int i=0;
    int j=0;
	int counter = 0;
	string tempSplitStr = "";
	
	
    if (line.length() == 0)
	{
		return 0;
	}
	line = line + delimiter;
	for (i = 0; i < line.length(); i++)
	{

    	if(line[i] != delimiter)
    	{
    		tempSplitStr += line[i];
        }

	    else
	    {
	    	if(tempSplitStr != "")
	    	{
		    	arr[j] = tempSplitStr;
			 	tempSplitStr = "";
		      	j++;
	    	}
	    }
	}
	return counter;
}

int readBooks(string fileName, Book books[],int numBookStored,int booksArrSize)
{
    int i = 0;
    int lineCounter = numBookStored;
    char delimiter= ',';
    string splitVal[2];
    string lines;
    ifstream inputFile;
    inputFile.open(fileName);
    
    if(inputFile.fail())//edge case check
    {
        return -1;
    }
   if (inputFile.is_open())
   {

        if (numBookStored == booksArrSize)//edge case check
        {
            return -2;
        }
      while(getline(inputFile, lines) && lineCounter < booksArrSize)
      {
        if (lines== "")//edge case check
        {
            lines = "";
        }
        
        else 
        {
            split(lines, delimiter, splitVal);
            books[lineCounter].setAuthor(splitVal[0]);//stores values from authors into new array at index 0
            books[lineCounter].setTitle(splitVal[1]);//stores values from titles into new array at index 0
            
            lineCounter++;
        }
         
      }

   }
   

    return lineCounter;
   inputFile.close();
}


// Print all books
string printAllBooks(Book books[],int numOfBooks)
{

   if (numOfBooks <=0)//edge case check
   {
      cout<< "No books are stored"<<endl;
   }
   else
   {
      cout<<"Here is a list of books "<<endl;
      for(int i=0; i < numOfBooks; i++)
      {
         cout << books[i].getTitle() << " by " << books[i].getAuthor() << endl;// prints titles by authors in respective index
      }   
   }
}


// Print books by author
void printBooksByAuthor(Book books[],int numOfBooks, string authorName)
{
   int authorCount=0;
   if (numOfBooks <=0)//edge case check
   {
      cout<< "No books are stored"<<endl;
      return;
   }
   
   for(int i = 0; i < numOfBooks; i++) 
   {
      if(books[i].getAuthor() == authorName)
      {
         authorCount++;
      }
   }
   if (authorCount <= 0)//edge case check
   {
      cout<<"There are no books by "<< authorName<<endl;
      return;
   }
   cout<<"Here is a list of books by "<< authorName <<endl;
   for(int i=0; i < numOfBooks; i++)
   {
      if (books[i].getAuthor() == authorName)
      {
         cout << books[i].getTitle() << endl;
         authorCount++;
      }
   }
}

////Use bookUnityHw6 for testing
int main()
{
    int choice;
    char t;
    int numBooks;
    Book books[50];
	while (choice != '4')
	{
		printMenu();
		cin>>choice;
		cin.get(t);
		
		
		
		    if(choice != 1 && choice != 2 && choice != 3 && choice != 4)
			{
				cout<< "Invalid input."<< endl;
			}
			else if (choice == 4)
			{
				cout<< "Good bye!"<<endl;
				return 0;
			}
			else{
						switch(choice)
						{	
						    case 1:
						    {
							string fileName;
							int booksArrSize = 50 ;
						    cout<< "Enter a book file name: "<<endl;
				    	    getline (cin, fileName);
				    	    numBooks = readBooks(fileName, books, numBooks ,booksArrSize);
						    
						    if( numBooks == -1 )
						    {
						        cout<< "No books saved to the database."<<endl;
						        continue;
						    }
						    if(numBooks == -2)
						    {
						        cout<< "Database is already full. No books were added."<<endl;
						        continue;
						    }
						    if (numBooks == booksArrSize)
						    {
						        cout<< "Database is full. Some books may have not been added."<<endl;
						        continue;
						    }
						    else
						    {
						        cout<<"Total books in the database: "<< numBooks <<endl;
						    }
						    break;
						    }
						    
						    case 2:
						    {
						        int numOfBooks = numBooks;
						        printAllBooks(books, numOfBooks);
				            break;
						    }
						    
						    case 3:
						    {
						    string author;
						    cout<< "Enter name of author: "<<endl;
						    getline (cin, author);
				            printBooksByAuthor(books, numBooks, author);
				            break;
						    }
						}
				}
			
	}
}