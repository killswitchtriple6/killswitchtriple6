//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni
//Homework 6 - Problem 1

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include "planet.h"

using namespace std;


int main()
{
	Planet newPlanet; 
	newPlanet.setName("nebraska");
	newPlanet.setRadius(866.23);
	
	
	//test initialization
	string planetName = newPlanet.getName();
	double planetRadius = newPlanet.getRadius();
	double planetVolume = newPlanet.getVolume();
	newPlanet = Planet();
	newPlanet = Planet("nebraska", 866.23);
	cout<< planetName<<endl;
	cout<<planetRadius<<endl;
	cout<<planetVolume<<endl;
	
	
}