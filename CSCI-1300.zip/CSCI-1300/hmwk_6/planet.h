//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni
//Homework 6 - Problem 1

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

using namespace std;

#ifndef PLANET_H
#define PLANET_H


class Planet
{
	private:
	string planetName;
	double planetRadius;
	
	public:
	Planet();
	Planet(string name, double radius);
	
	//getters
	string getName();
	double getRadius();
	double getVolume();
	
	//setters
	void setName(string newName);
	void setRadius(double newRadius);

};

#endif