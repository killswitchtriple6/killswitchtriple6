//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni
//Homework 6 - Problem 3

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include "book.h"
using namespace std;

Book :: Book()
{
	bookTitle="";
	bookAuthor="";
}
Book :: Book(string title, string author)
{
	bookTitle = title;
	bookAuthor = author;
}
string Book :: getTitle()
{
	return bookTitle;
}

void Book :: setTitle(string title)
{
	bookTitle = title;
}

string Book :: getAuthor()
{
	return bookAuthor;
}

void Book :: setAuthor(string author)
{
	bookAuthor = author;
}

