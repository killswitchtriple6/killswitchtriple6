//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni
//Homework 6 - Problem 3

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include "book.h"

using namespace std;


int main()
{
	Book newBook; 
	newBook.setTitle("Author X");
	newBook.setAuthor("Book Y");
	
	
	//test initialization
	string bookTitle = newBook.getTitle();
	string bookAuthor = newBook.getAuthor();
	newBook = Book();
	newBook = Book("Author X", "Book Y");
	cout<< bookTitle <<endl;
	cout<< bookAuthor <<endl;

	
	
}