//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni
//Homework 6 - Problem 1

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <cmath>
#include "planet.h"
using namespace std;

Planet :: Planet()
{
	planetName="";
	planetRadius=0.0;
}
Planet :: Planet(string name, double radius)
{
	planetName = name;
	planetRadius = radius;
}
string Planet :: getName()
{
	return planetName;
}

void Planet :: setName(string name)
{
	planetName = name;
}

double Planet :: getRadius()
{
	return planetRadius;
}

void Planet :: setRadius(double radius)
{
	planetRadius = radius;
}

double Planet :: getVolume()
{
	double planetVolume;
	planetVolume = (4.0/3.0) * M_PI * pow(planetRadius , 3.0);//volume formula
}
