//CSCI 1300 Fall 2019
//Author: Matt Promboon
//Recitation: 101 - D. Soni
//Homework 6 - Problem 3
#ifndef BOOK_H
#define BOOK_H

#include <cctype>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>

using namespace std;



class Book
{
	private:
	string bookTitle;
	string bookAuthor;
	
	public:
	Book();
	Book(string bookTitle, string bookAuthor);
	//getters
	string getTitle();
	string getAuthor();
	//setters
	void setTitle(string newTitle);
	void setAuthor(string newAuthor);

};

#endif