#include <iostream>
using namespace std;

void classGreeting (int course)
{
    cin >> course;
    cout << "Hello, CS "<< course << " World!"<< endl;
}    


int main()
{
    int course;
    classGreeting(course);

    return 0;
}