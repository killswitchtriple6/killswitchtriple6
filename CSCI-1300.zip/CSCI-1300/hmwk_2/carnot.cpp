#include <iostream>
#include <math.h>
using namespace std;

float carnot(int temperatureC, int temperatureH)
{
    //double temperatureH; //hot temperature
   // double temperatureC;// cold temperature
   float carnot = 0.0;
    carnot = 1 - (float(temperatureC))/(float(temperatureH)); //formula for carnot efficiency
    cout << carnot << endl;
   return carnot;
}

int main()
{
    cout << "Enter the hot temperature: ";
    float temperatureH;
    cin >> temperatureH;
    cout << "Enter the cold temperature: ";
    float temperatureC;
    cin >> temperatureC;
    carnot (temperatureC,temperatureH);
    cout << carnot << endl;
}