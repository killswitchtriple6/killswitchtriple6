#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

int population (int population)
{

    int secondsInYear = 365*24*60*60;// takes seconds in a year
    int birth = secondsInYear/8;// person born every 8 seconds
    int death = secondsInYear/12;// person dies ever 12 seconds
    int immigrant = secondsInYear/27;//immigrant enters every 27 seconds
    population = population + birth - death + immigrant;// add numbers to get final population
    
    return population;
}

int main()
{
    int initialPopulation;
    cout << "What is the initial population? ";
    cin >> initialPopulation;
    int finalPopulation = population(initialPopulation);
	cout << finalPopulation << endl;
	return 0;
}
