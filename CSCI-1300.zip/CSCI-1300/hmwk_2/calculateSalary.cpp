#include <iostream>
using namespace std;

int calculateSalary(int rain, int cold, int sun)
{
    int pay = 10;
    int rainDay = 5; // hours on a rainy day
    int coldDay = 4; // hours on a cold day
    int sunnyDay = 8; //hours on a sunny day
    int totalDays = rain * rainDay + cold * coldDay + sun * sunnyDay;
    int totalPay = totalDays * pay;
    return totalPay;
}
 
int main( )
{
    int rain, cold, sun;
    cout << "Rainy days: ";
    cin >> rain;
    cout << "Cold days: ";
    cin >> cold;
    cout << "Sunny days: ";
    cin >> sun;
    
    
    cout << "Total pay: " << calculateSalary(rain, cold, sun);
    return 0;
}