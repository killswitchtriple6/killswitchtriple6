#include <iostream>
#include <math.h>
using namespace std;

int main(){
    cout << "Enter a radius: " << endl;
    double radius;
    cin >> radius;
    double volume;
    double surfaceArea;
    volume = (4.0/3.0) * M_PI * pow(radius, 3);//formula for calculating volume
    surfaceArea = (4.0) * M_PI * pow(radius, 2);//formula for calculating SA
    cout << "volume: " << volume << endl; 
    cout << "surface area: " << surfaceArea << endl;
    
    
   
}