#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

void convertSeconds (int second)
{   
    int minutes = second/60.0;// finds minutes
    int seconds = second % 60;//finds seconds from remainder
    int hours = minutes/60;//finds hours
    minutes = minutes % 60;// finds minutes from remainder
    
    
    
    cout << hours << " hour(s) " << minutes << " minute(s) " << seconds << " second(s) " << endl;
}

int main()
{
    cout <<"How many seconds? ";
    int second;
    cin >> second;
    convertSeconds(second);
    return 0;	
}