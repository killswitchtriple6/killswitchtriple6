#include <iostream>
#include <math.h>
using namespace std;

void sphereVolume(double radius)
{
    cout << "Enter a radius: " << endl;
    cin >> radius ;
    double volume = (4.0/3.0) * M_PI * pow(radius, 3); //formula for finding volume
    cout << "volume: " << volume << endl;
    
}

int main()
{
    double volume;
    sphereVolume(volume);
    return 0;
  
}