#include <iostream>
using namespace std;

int main()
{
    int course;
    cout << "Enter a CS course number " ;
    cin >> course;
    cout << "Hello, CS "<< course << " World!"<< endl;
    return 0;
}