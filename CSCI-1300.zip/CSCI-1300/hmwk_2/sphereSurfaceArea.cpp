#include <iostream>
#include <math.h>
using namespace std;

void sphereSurfaceArea(double radius)
{
    cout << "Enter a radius: " << endl;
    cin >> radius ;
    double surfaceArea = (4.0) * M_PI * pow(radius, 2);// formula for calculating surface area
    cout << "surface area: " << surfaceArea << endl;
    
}

int main()
{
    double surfaceArea;
    sphereSurfaceArea(surfaceArea);
    return 0;
  
}